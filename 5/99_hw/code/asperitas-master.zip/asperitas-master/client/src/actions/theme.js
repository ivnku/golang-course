export const TOGGLE_DARK_THEME = 'TOGGLE_DARK_THEME';
export const toggleDarkTheme = () => ({ type: TOGGLE_DARK_THEME });
