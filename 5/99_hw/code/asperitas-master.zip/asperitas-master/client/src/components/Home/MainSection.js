import styled from 'styled-components/macro';

const HomeMainSection = styled.main`
  flex: 1;
  min-width: 0;
`;

export default HomeMainSection;
