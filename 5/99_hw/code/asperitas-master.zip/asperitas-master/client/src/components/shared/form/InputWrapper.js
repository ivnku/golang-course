import styled from 'styled-components/macro';

const InputWrapper = styled.div`
  position: relative;
  margin-bottom: 24px;
  width: 100%;
`;

export default InputWrapper;
